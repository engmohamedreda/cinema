<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	if(!$Cinema->isLoggedIn()) redirect('../');
	
	$Hall = new Hall();
	
	if(!set('id') || !$Hall->get(get('id'))) redirect('./');
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Hall->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Hall->name() ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="halls.php" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
					
						<form method="post">
	
							<?php
							
							$disabled = "";
							
							if(set('delete')){
								if($Hall->remove(get('id'))) $disabled = "disabled";
								else echo'<div class="alert alert-danger">'.$Hall->error().'</div>';
							}
	
							if(set('submit')){
								
								if($Hall->update(get('id'), post('name'), post('rows'), post('columns'))) refresh();
								else echo'<div class="alert alert-danger">'.$Hall->error().'</div>';
								
							}
							?>
							
							<label>الاسم</label>
							<input type="text" name="name" class="login-input" value="<?= $Hall->name() ?>" />
							<div class="split"></div>
							<label>عدد صفوف الكراسى</label>
							<input type="number" name="rows" class="login-input" value="<?= $Hall->rows() ?>" />
							<div class="split"></div>
							<label>عدد الكراسى فى الصف الواحد</label>
							<input type="number" name="columns" class="login-input" value="<?= $Hall->columns() ?>" />
							<div class="split"></div>
							<button class="form-submit" type="submit" name="submit" <?= $disabled ?>>
								حفظ
							</button>
							
						</form>
						
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<button href="javascript:void(0)" id="deleteAction" class="danger-link" <?= $disabled ?>>
									حذف
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
		
		<div class="modal" id="deleteMessage" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-footer">
						<div class="row">
							<div class="col-md-12 text-right">
								هل انت متاكد من الحذف
								<hr>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="danger-link" data-dismiss="modal">لا</button>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="success-link" id="deleteYes">نعم</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
			
			$("#deleteAction").click(function(){
				$("#deleteMessage").modal("show");
			});
		
			$("#deleteYes").click(function(){
				window.location = "<?= $_SERVER['PHP_SELF'] ?>?id=<?=get('id')?>&delete=yes";
			});
		
		</script>
		
	</body>
</html>