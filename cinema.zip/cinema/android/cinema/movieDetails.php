<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	if(!$Cinema->isLoggedIn()) redirect('../');
	if(!$Cinema->status()) redirect('./wait.php');
	
	$Movie = new Movie();
	
	if(!set('id') || !$Movie->get(get('id'))) redirect('./');
	
	if($Movie->cinema()->id() != $Cinema->id()) redirect('./');
	
	$back = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "./";
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Movie->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Movie->name() ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="<?= $back ?>" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
				
						<?php
						
						$disabled = "";
						
						if(set('delete')){
							if($Movie->remove(get('id'))) $disabled = "disabled";
							else echo'<div class="alert alert-danger">'.$Movie->error().'</div>';
						}

						?>
						
						<form method="post" enctype="multipart/form-data">
	
							<?php
								if(set('submit')){
									
									$Movie = new Movie();
									
									$name = post('name');
									$description = post('description');
									$photo = files('file');
									$times = post('times');
									
									if($Movie->update(get('id'), $name, $description, $photo, $times)){
										echo'<div class="alert alert-success"> تم الحفظ بنجاج </div>';
										$Movie->get(get('id'));
									}else echo'<div class="alert alert-danger">'.$Movie->error().'</div>';
									
								}else{
									?>
								<div class="alert alert-info">برجاء ادخال البيانات المطلوبة</div>
									<?php
								}
							?>
								
							<label>الاسم</label>
							<input type="text" name="name" class="login-input" value="<?= $Movie->name() ?>" />
							<div class="split"></div>
							
							<label>الوصف</label>
							<textarea name="description" class="login-input"><?= $Movie->description() ?></textarea>
							<div class="split"></div>
							
							<label>تاريخ بداية العرض</label>
							<br>
							<?= $Movie->start_date() ?>
							<div class="split"></div>
						
							<label>تاريخ نهاية العرض</label>
							<br>
							<?= $Movie->end_date() ?>
							<div class="split"></div>
						
							<label>اوقات العرض</label>
							<br>
							<?php
							
								foreach($movies_times as $time){
									$checked = in_array($time, $Movie->times()) ? "checked" : "";
									?>
									
										<a href="javascript:void(0)" class="checkbox-label">
											 <?= $time ?> <input class="item" type="checkbox" name="times[]" value="<?= $time ?>" <?= $checked ?>>
										</a>
							
									<?php
								}
							
							?>
							
							<div class="split"></div>
						
							<label>القسم</label>
							<br>
							<?= $Movie->section()->name() ?>
							<div class="split"></div>
						
							<label>القاعة</label>
							<br>
							<?= $Movie->hall()->name() ?>
							<div class="split"></div>
						
							<label>السينما</label>
							<br>
							<?= $Movie->cinema()->name() ?>
							<div class="split"></div>
						
							<label>صورة العرض</label>
							<br>
							<img src="../../uploads/<?= $Movie->photo() ?>" style="max-width: 500px; width: 90%;">
							<div class="split"></div>
							<input type="file" name="file" class="login-input" />
							<div class="split"></div>
							<button class="form-submit" type="submit" name="submit">
								حفظ
							</button>
							
						
						</form>
						
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<button href="javascript:void(0)" id="deleteAction" class="danger-link" <?= $disabled ?>>
									حذف
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
		
		<div class="modal" id="deleteMessage" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-footer">
						<div class="row">
							<div class="col-md-12 text-right">
								هل انت متاكد من الحذف
								<hr>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="danger-link" data-dismiss="modal">لا</button>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="success-link" id="deleteYes">نعم</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
			
			$("#deleteAction").click(function(){
				$("#deleteMessage").modal("show");
			});
		
			$("#deleteYes").click(function(){
				window.location = "<?= $_SERVER['PHP_SELF'] ?>?id=<?=get('id')?>&delete=yes";
			});
		
			$(".checkbox-label").click(function(){
				
				if($(this).find(".item").is(':checked')) $(this).find(".item").attr("checked", false);
				else $(this).find(".item").attr("checked", true);
				
			});
			
		</script>
		
	</body>
</html>