<?php
	require_once('../../php_includes/controller.php');
	$Client = new Client();
	if(!$Client->isLoggedIn()) redirect('../');
	
	$Registration = new Registration();
	
	if(!set('id') || !$Registration->get(get('id'))) redirect('./');
	$urlLocation = set('backurl') ? get('backurl') : "registrations.php";
	
	$back = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "./";
	
	if(set('rate') && !$Registration->rating()){
		if(!$Registration->setRating(get('id'), get('rate'))){
			echo '<script> alert("'.$Registration->error().'"); </script>';
		}else header('location: registration.php?id='.get('id'));
	}
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Registration->movie()->name(); ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
		<link href="../../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Registration->movie()->name(); ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="registrations.php" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
				
						<?php
							
							$showRatingModal = false;
							
							if(strtotime(date('Y-m-d')) > strtotime($Registration->regdate())){
								
								if(!$Registration->rating()){
									?>
										<button href="javascript:void(0)" id="setRate" class="success-link">
											تقييم
										</button>
										<hr>
									<?php
									$showRatingModal = true;
								}else{
									?>
									<label>التقييم</label>
									<br>
									<?php
									
									echo $Registration->rating() > 4 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
									echo $Registration->rating() > 3 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
									echo $Registration->rating() > 2 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
									echo $Registration->rating() > 1 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
									echo $Registration->rating() > 0 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
									
									echo '<div class="split"></div>';
									
								}
								
								$disabled = "disabled";
								
							}else{
								
								$disabled = "";
								
								if(set('delete')){
									if($Registration->remove(get('id'))) $disabled = "disabled";
									else echo'<div class="alert alert-danger">'.$Registration->error().'</div>';
								}

							}
						
						?>
					
						<label>تاريخ الحجز</label>
						<br>
						<?= $Registration->regdate() ?>
						<div class="split"></div>
					
						<label>وقت الحجز</label>
						<br>
						<?= $Registration->regtime() ?>
						<div class="split"></div>
					
						<label>المقاعد</label>
						<br>
						<?= implode(" - " , $Registration->chairs()) ?>
						<div class="split"></div>
					
						<label>السينما</label>
						<br>
						<a class="info-link" href="cinema.php?id=<?= $Registration->cinema()->id() ?>&backurl=registration.php?id=<?= $Registration->id() ?>"><?= $Registration->cinema()->name() ?></a>
						<div class="split"></div>
					
						<label>الفيلم</label>
						<br>
						<a class="info-link" href="movie.php?id=<?= $Registration->movie()->id() ?>&backurl=registration.php?id=<?= $Registration->id() ?>"><?= $Registration->movie()->name() ?></a>
						<div class="split"></div>
					
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<button href="javascript:void(0)" id="deleteAction" class="danger-link" <?= $disabled ?>>
									الغاء
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
		
		<div class="modal" id="deleteMessage" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-footer">
						<div class="row">
							<div class="col-md-12 text-right">
								الغاء الحجز
								<hr>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="danger-link" data-dismiss="modal">لا</button>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="success-link" id="deleteYes">نعم</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="modal" id="setRateModal" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-footer">
						<div class="row">
							<div class="col-12 text-right">
								تقييم
								<hr>
							</div>
							<div class="col-12 text-right">
								<a href="registration.php?id=<?= get('id') ?>&rate=5&backurl=<?= $urlLocation ?>" class="rate-star">
									<i class="fa fa-star"></i>
								</a>
								<a href="registration.php?id=<?= get('id') ?>&rate=4&backurl=<?= $urlLocation ?>" class="rate-star">
									<i class="fa fa-star"></i>
								</a>
								<a href="registration.php?id=<?= get('id') ?>&rate=3&backurl=<?= $urlLocation ?>" class="rate-star">
									<i class="fa fa-star"></i>
								</a>
								<a href="registration.php?id=<?= get('id') ?>&rate=2&backurl=<?= $urlLocation ?>" class="rate-star">
									<i class="fa fa-star"></i>
								</a>
								<a href="registration.php?id=<?= get('id') ?>&rate=1&backurl=<?= $urlLocation ?>" class="rate-star">
									<i class="fa fa-star"></i>
								</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
			
			$("#deleteAction").click(function(){
				$("#deleteMessage").modal("show");
			});
		
			$("#setRate").click(function(){
				$("#setRateModal").modal("show");
			});
		
			$("#deleteYes").click(function(){
				window.location = "<?= $_SERVER['PHP_SELF'] ?>?id=<?=get('id')?>&delete=yes";
			});
		
			<?php
			
				if($showRatingModal){
					?>
			$("#setRateModal").modal("show");
					<?php
				}
			
			?>
		
		</script>
		
	</body>
</html>