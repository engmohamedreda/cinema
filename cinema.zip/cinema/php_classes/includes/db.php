<?php

define('host', 'localhost');
define('username', 'root');
define('password', '');
define('database', 'cinema');
define('charset', 'utf8');

class db{
	
	private $id = 0, $rows = 0;
	private $sql = "", $error = "";
	
	private $result;
	private $results;
	private $connect;
	
	public function __construct(){
		$this->connect = new mysqli(host,username,password,database);
		$this->connect->connect_errno ? $this->error = 'database connection error' : $this->connect->set_charset(charset);
	}
	
	public function __destruct(){
		$this->connect->close();
	}
	
	public function sql($sql = null){
		if(!empty($sql)) $this->sql = $sql;
		return $this->sql;
	}
	
	public function execute(){
		
		if(empty($this->sql)){
			$this->error = "empty statement";
			return false;
		}
		
		$this->result = $this->connect->query($this->sql);
		
		if(!$this->result){
			$this->error = $this->connect->error;
			return false;
		}
		
		return true;
		
	}
	
	public function rows(){
		if($this->result != null) $this->rows = $this->result->num_rows;
		return $this->rows;
	}
	
	public function results(){
		if($this->result == null) return [];
		$results = [];
		while($result = $this->result->fetch_array()) $results[] = $result;
		$this->results = $results;
		return $this->results;
	}
	
	public function error(){
		return $this->error;
	}
	
	public function lastresults(){
		return $this->results;
	}
	
	public function id(){
		return $this->connect->insert_id;
	}
	
	public function connect(){
		return $this->connect;
	}
	
}

?>