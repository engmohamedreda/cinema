<?php

class Cinema implements User{
	
	private $name = null, $email = null, $phone = null, $description = null,
			$country = null, $governorate = null, $password = null, $region = null,
			$picture = null;
			
	private $status = 0;
			
	private $id = 0;
	
	private $error;
	
	public function __construct($id = 0, $name = null, $email = null, $phone = null, $description = null,
			$country = null, $governorate = null, $region = null,
			$picture = null, $password = null, $status = 0){
		$this->id = $id;
		$this->name = $name;
		$this->email = $email;
		$this->phone = $phone;
		$this->description = $description;
		$this->country = $country;
		$this->governorate = $governorate;
		$this->region = $region;
		$this->password = $password;
		$this->picture = $picture;
		$this->status = $status;
	}
	
	public function addUser($name, $email, $phone, $description, $country, $governorate, $region, $picture, $passwordConf, $password){
		
		if(empty($email) || empty($name) || empty($country) ||
			empty($governorate) || empty($region) || empty($password) || empty($picture)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if($password != $passwordConf){
			$this->error = "كلمة السر غير متطابقة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `cinema` where `email` = '{$email}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم المستخدم مسجل مسبقا";
			return false;
		}
		
		$rand = rand();
		
		$pictureExtension = "." . pathinfo($picture['name'], PATHINFO_EXTENSION);
		$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
		
		
		while(file_exists($picturePath)){
			$rand = rand();
			$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
		}
		
		if(!@move_uploaded_file($picture['tmp_name'], $picturePath)){
			$this->error = "خطأ فى تحميل الملف";
			return false;
		}
		
		$picture = $rand . $pictureExtension;
		
		$db->sql("INSERT INTO `cinema`(`name`, `email`, `phone`, `description`, `country`, `governorate`, `region`, `picture`, `password`)".
					" VALUES('{$name}', '{$email}', '{$phone}', '{$description}', '{$country}', '{$governorate}', '{$region}', '{$picture}', '{$password}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function getUser($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `cinema` where `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$user = $db->results()[0];
		
		$this->id = $user['id'];
		$this->name = $user['name'];
		$this->email = $user['email'];
		$this->phone = $user['phone'];
		$this->description = $user['description'];
		$this->country = $user['country'];
		$this->governorate = $user['governorate'];
		$this->region = $user['region'];
		$this->picture = $user['picture'];
		$this->password = $user['password'];
		$this->status = $user['status'];
		
		return true;
		
	}
	
	public function getRating($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `registration` where `cinema_id` = '{$id}' and `rating` <> '0'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return 0;
		}
		
		$rating = 0;
		$users = 0;
		
		foreach($db->Results() as $result){
			$rating += $result['rating'];
			$users++;
		}
		
		return $rating && $users ? ($rating / $users) : 0;
		
	}
	
	public function getUsers(){
		
		$db = new db();
		
		$db->sql("select * from `cinema` where `status` = '1'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$users = [];
		foreach($db->results() as $user) 
			$users[] = new Cinema(
									$user['id'],
									$user['name'],
									$user['email'],
									$user['phone'],
									$user['description'],
									$user['country'],
									$user['governorate'],
									$user['region'],
									$user['picture'],
									$user['password'],
									$user['status']
								);
		
		return $users;
		
	}
	
	public function getClientCinemas($client){
		
		$db = new db();
		
		$db->sql("select * from `cinema` where `status` = '1' and `id` in (select `cinema_id` from `registration` where `client_id` = '{$client}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$users = [];
		foreach($db->results() as $user) 
			$users[] = new Cinema(
									$user['id'],
									$user['name'],
									$user['email'],
									$user['phone'],
									$user['description'],
									$user['country'],
									$user['governorate'],
									$user['region'],
									$user['picture'],
									$user['password'],
									$user['status']
								);
		
		return $users;
		
	}
	
	public function getNewUsers(){
		
		$db = new db();
		
		$db->sql("select * from `cinema` where `status` = '0'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$users = [];
		foreach($db->results() as $user) 
			$users[] = new Cinema(
									$user['id'],
									$user['name'],
									$user['email'],
									$user['phone'],
									$user['description'],
									$user['country'],
									$user['governorate'],
									$user['region'],
									$user['picture'],
									$user['password'],
									$user['status']
								);
		
		return $users;
		
	}
	
	public function removeUser($id){
		
		if(!$this->getUser($id)){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
	
		$db = new db();
		
		$db->sql("DELETE FROM `cinema` WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		@unlink( __DIR__ ."/../uploads/" . $this->picture);
		
		return true;
		
	}
	
	public function activate($id){
		
		if(!$this->getUser($id)){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$db = new db();
		
		$db->sql("UPDATE `cinema` SET `status` = '1' WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function updateUser($id, $name, $email, $phone, $description, $country, $governorate, $region, $picture, $passwordConf, $password){
		
		if(empty($email) || empty($name) || empty($country) ||
			empty($governorate) || empty($region)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if(!$this->getUser($id)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `cinema` where `email` = '{$email}' AND `id` <> '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم المستخدم مسجل مسبقا";
			return false;
		}
		
		if(!empty($password)){
				
			if($password != $passwordConf){
				$this->error = "كلمة السر غير متطابقة";
				return false;
			}
			
			$db->sql("UPDATE `cinema` SET `password` = '{$password}' WHERE `id` = '{$id}'");
			
			if(!$db->execute()){
				$this->error = "خطأ فى التنفيذ";
				return false;
			}
			
		}
		
		if(!empty($picture)){
			
			$rand = rand();
			
			$pictureExtension = "." . pathinfo($picture['name'], PATHINFO_EXTENSION);
			$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
			
			
			while(file_exists($picturePath)){
				$rand = rand();
				$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
			}
			
			$old = "/../uploads/" . $this->picture;
			
			if(!@move_uploaded_file($picture['tmp_name'], $picturePath)){
				$this->error = "خطأ فى تحميل الملف";
				return false;
			}
			
			@unlink( __DIR__ .$old);
			
			$picture = $rand . $pictureExtension;
		
			$db->sql("UPDATE `cinema` SET `picture` = '{$picture}' WHERE `id` = '{$id}'");
			
			if(!$db->execute()){
				$this->error = "خطأ فى التنفيذ";
				return false;
			}
			
		}
		
		$db->sql("UPDATE `cinema` SET `name` = '{$name}',`email` = '{$email}',`phone` = '{$phone}',`description` = '{$description}',`country` = '{$country}',`governorate` = '{$governorate}',`region` = '{$region}' WHERE `id` = '{$id}'");
			
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function login($email, $password){
		
		if(empty($email) || empty($password)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `cinema` where `email` = '{$email}' and `password` = '{$password}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ" . $db->error();
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$id = $db->results()[0]['id'];
		
		sign('cinema', $id);
		
		return true;
		
	}
	
	public function isLoggedIn(){
		 return is_signed('cinema') && $this->getUser(signed('cinema'));
	}
	
	public function logout(){
		removeSign('cinema');
	}
	
	public function setid($id){
		$this->id = $id;
	}
	
	public function error(){
		return $this->error;
	}
	
	public function id(){
		return $this->id;
	}
	
	public function name(){
		return $this->name;
	}
	
	public function email(){
		return $this->email;
	}
	
	public function phone(){
		return $this->phone;
	}
	
	public function description(){
		return $this->description;
	}
	
	public function country(){
		return $this->country;
	}
	
	public function governorate(){
		return $this->governorate;
	}
	
	public function picture(){
		return $this->picture;
	}
	
	public function region(){
		return $this->region;
	}
	
	public function password(){
		return $this->password;
	}
	
	public function status(){
		return $this->status;
	}
	
}

?>