<?php
	
	require_once('../../php_includes/controller.php');
	$Client = new Client();
	if(!$Client->isLoggedIn()) redirect('../');
	
	$Movie = new Movie();
	$Registration = new Registration();
	
	if(!set('movie') || !set('date') || !set('time') || !set('chairs') || !$Movie->get(post('movie'))){
		echo'<div class="alert alert-danger">من فضلك ادخل البيانات المطلوبة</div>';
		return;
	}

	if($Registration->add(post('date'),post('time'),post('chairs'),$Movie->id(),$Client->id())){
		echo'<div class="alert alert-success"> تم الحجز بنجاج </div>';
		echo'<script> 
				$("#showChairs").attr("disabled", true);
				$("#registration").attr("disabled", true);
			</script>';
	}else{
		echo'<div class="alert alert-danger">'.$Registration->error().'</div>';
	}	