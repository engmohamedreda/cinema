<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	$Cinema->logout();
	redirect('../');