<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	if(!$Cinema->isLoggedIn()) redirect('../');
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Cinema->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Cinema->name() ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="index.php" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
					
						<form method="post" enctype="multipart/form-data">
	
							<?php
								if(set('submit')){
									
									$email = post('email');
									$phone = post('phone');
									$region = post('region');
									$description = post('description');
									$picture = !empty(files('file')['tmp_name']) ? files('file') : null;
									$password = post('password');
									$passwordConf = post('password_confirm');
									
									if($Cinema->updateUser($Cinema->id(), $Cinema->name(), $email, $phone, $description, $Cinema->country(), $Cinema->governorate(), $region, $picture, $passwordConf, $password)){
										echo'<div class="alert alert-success"> تم التعديل بنجاج </div>';
										$Cinema->getUser($Cinema->id());
									}else echo'<div class="alert alert-danger">'.$Cinema->error().'</div>';
									
								}else{
									?>
								<div class="alert alert-info">برجاء ادخال البيانات المطلوبة</div>
									<?php
								}
							?>
							<label>الاسم</label>
							<input type="text" name="name" class="login-input" value="<?= $Cinema->name() ?>" disabled />
							<div class="split"></div>
							<label>البريد الالكترونى</label>
							<input type="text" name="email" class="login-input" value="<?= $Cinema->email() ?>" />
							<div class="split"></div>
							<label>رقم الهاتف</label>
							<input type="text" name="phone" class="login-input" value="<?= $Cinema->phone() ?>" />
							<div class="split"></div>
							<label>البلد</label>
							<select name="country" class="login-input" disabled>
								<option value="مصر">مصر</option>
							</select>
							<div class="split"></div>
							<label>المحافظة</label>
							<select name="governorate" class="login-input" disabled>
								<option value="<?= $Cinema->governorate() ?>"><?= $Cinema->governorate() ?></option>
								<?php
									foreach($governorates as $gov) echo '<option value="'.$gov.'">'.$gov.'</option>';
								?>
							</select>
							<div class="split"></div>
							<label>المنطقة</label>
							<input type="text" name="region" class="login-input" value="<?= $Cinema->region() ?>" />
							<div class="split"></div>
							<label>الوصف</label>
							<input type="text" name="description" class="login-input" value="<?= $Cinema->description() ?>" />
							<div class="split"></div>
							<label>صورة شخصية</label>
							<img src="../../uploads/<?= $Cinema->picture() ?>" height="100" class="right">
							<input type="file" name="file" class="login-input" />
							<div class="split"></div>
							<label>كلمة السر</label>
							<input type="password" name="password" class="login-input" />
							<div class="split"></div>
							<label>تاكيد كلمة السر</label>
							<input type="password" name="password_confirm" class="login-input" />
							<div class="split"></div>
							<button class="form-submit" type="submit" name="submit">
								حفظ
							</button>
							
						</form>
						
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
		
		<script>
			
		</script>
		
	</body>
</html>