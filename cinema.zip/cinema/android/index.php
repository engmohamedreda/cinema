<?php
	
	require_once('../php_includes/controller.php');
	
	$Administrator = new Administrator();
	if($Administrator->isLoggedIn()) redirect('Admin/');
	
	$Cinema = new Cinema();
	if($Cinema->isLoggedIn()) redirect('Cinema/');
	
	$Client = new Client();
	if($Client->isLoggedIn()) redirect('Client/');
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title>تسجيل دخول</title>
		
		<meta charset="utf-8">
		
		<link href="../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../css/style.css" rel="stylesheet" type="text/css">
		<link href="../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">
		
	</head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							تسجيل الدخول
						</div>
					</div>
					<div class="col-md-12 login-box">
						<form method="post">
	
							<?php
							if(set('submit')){
								
								$username = post('email');
								$password = post('password');
								
								if($Administrator->login($username, $password)) redirect('Admin/');
								else if($Cinema->login($username, $password)) redirect('Cinema/');
								else if($Client->login($username, $password)) redirect('Client/');
								else echo'<div class="alert alert-danger">'.$Client->error().'</div>';
								
							}else{
								?>
							<div class="alert alert-info">برجاء ادخال البيانات المطلوبة</div>
								<?php
							}
							?>
							<label>البريد الالكترونى</label>
							<input type="text" name="email" class="login-input" />
							<div class="split"></div>
							<label>كلمة السر</label>
							<input type="password" name="password" class="login-input" />
							<div class="split"></div>
							<button class="form-submit" type="submit" name="submit">
								دخول
							</button>
						</form>
						
					</div>
					<div class="col-md-12 externals">
						<a href="create.php" class="form-link">
							انشاء حساب
						</a>
                        <hr>
                        <a href="create4cinema.php" class="form-link">
                            انشاء حساب للسينمات
                        </a>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../js/jquery-3.3.1.min.js"></script>
		<script src="../js/bootstrap.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>