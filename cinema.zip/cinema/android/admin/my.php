<?php
	require_once('../../php_includes/controller.php');
	$Administrator = new Administrator();
	if(!$Administrator->isLoggedIn()) redirect('../');
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Administrator->username() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Administrator->username() ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="index.php" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
					
						<form method="post">
	
							<?php
							
							if(set('submit')){
								
								if($Administrator->updateUser($Administrator->id(),post('email'), post('password'), post('password_c'))) refresh();
								else echo'<div class="alert alert-danger">'.$Administrator->error().'</div>';
								
							}
							?>
							
							<label>اسم المستخدم</label>
							<input type="text" name="email" class="login-input" value="<?= $Administrator->username() ?>" />
							<div class="split"></div>
							<label>كلمة السر</label>
							<input type="password" name="password" class="login-input"  />
							<div class="split"></div>
							<label>تاكيد كلمة السر</label>
							<input type="password" name="password_c" class="login-input" />
							<div class="split"></div>
							<button class="form-submit" type="submit" name="submit">
								حفظ
							</button>
							
						</form>
						
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
		
		<script>
			
		</script>
		
	</body>
</html>