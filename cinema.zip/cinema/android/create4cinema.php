<?php
	
	require_once('../php_includes/controller.php');
	
	$Administrator = new Administrator();
	if($Administrator->isLoggedIn()) redirect('Admin/');
	
	$Cinema = new Cinema();
	if($Cinema->isLoggedIn()) redirect('Cinema/');
	
	$Client = new Client();
	if($Client->isLoggedIn()) redirect('Client/');
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title>انشاء حساب للسينمات</title>
		
		<meta charset="utf-8">
		
		<link href="../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../css/style.css" rel="stylesheet" type="text/css">
        <link href="../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							انشاء حساب للسينمات
						</div>
					</div>
					<div class="col-md-12 login-box">
						<form method="post" enctype="multipart/form-data">
							<?php
								if(set('submit')){
									
									$name = post('name');
									$email = post('email');
									$phone = post('phone');
									$country = post('country');
									$governorate = post('governorate');
									$region = post('region');
									$description = post('description');
									$picture = files('file');
									$password = post('password');
									$passwordConf = post('password_confirm');
									
									if($Cinema->addUser($name, $email, $phone, $description, $country, $governorate, $region, $picture, $passwordConf, $password)) echo'<div class="alert alert-success"> تم الانشاء بنجاج </div>';
									else echo'<div class="alert alert-danger">'.$Cinema->error().'</div>';
									
								}else{
									?>
								<div class="alert alert-info">برجاء ادخال البيانات المطلوبة</div>
									<?php
								}
							?>
							<label>الاسم</label>
							<input type="text" name="name" class="login-input" />
							<div class="split"></div>
							<label>البريد الالكترونى</label>
							<input type="text" name="email" class="login-input" />
							<div class="split"></div>
							<label>رقم الهاتف</label>
							<input type="text" name="phone" class="login-input" />
							<div class="split"></div>
							<label>البلد</label>
							<select name="country" class="login-input">
								<option value="مصر">مصر</option>
							</select>
							<div class="split"></div>
							<label>المحافظة</label>
							<select name="governorate" class="login-input">
								<?php
									foreach($governorates as $gov) echo '<option value="'.$gov.'">'.$gov.'</option>';
								?>
							</select>
							<div class="split"></div>
							<label>المنطقة</label>
							<input type="text" name="region" class="login-input" />
							<div class="split"></div>
							<label>الوصف</label>
							<input type="text" name="description" class="login-input" />
							<div class="split"></div>
							<label>صورة شخصية</label>
							<input type="file" name="file" class="login-input" />
							<div class="split"></div>
							<label>كلمة السر</label>
							<input type="password" name="password" class="login-input" />
							<div class="split"></div>
							<label>تاكيد كلمة السر</label>
							<input type="password" name="password_confirm" class="login-input" />
							<div class="split"></div>
							<button class="form-submit" type="submit" name="submit">
								انشاء حساب
							</button>
						</form>
						
					</div>
					<div class="col-md-12 externals">
						<a href="index.php" class="form-link">
							تسجيل دخول
						</a>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../js/jquery-3.3.1.min.js"></script>
		<script src="../js/bootstrap.js"></script>
		<script src="../js/custom.js"></script>
	</body>
</html>