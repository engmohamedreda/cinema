<?php

ob_start();

if(session_status() == PHP_SESSION_NONE) session_start();

function set($key){
	return isset($_REQUEST[$key]);
}

function post($key){
	if(!isset($_POST[$key])) return null;
	if(is_array($_POST[$key])){
		$returns = [];
		foreach($_POST[$key] as $ar_key => $ar_val) $returns[$ar_key] = addslashes($ar_val);
		return $returns;
	}else return addslashes($_POST[$key]);
}

function files($key){
	return isset($_FILES[$key]['tmp_name']) ? $_FILES[$key] : null;
}

function get($key){
	return isset($_GET[$key]) ? $_GET[$key] : null;
}

function sign($key, $val){
	$_SESSION[$key] = $val;
}

function is_signed($key){
	return isset($_SESSION[$key]);
}

function signed($key){
	return isset($_SESSION[$key]) ? $_SESSION[$key] : null;
}

function removeSign($key){
	if(isset($_SESSION[$key])) unset($_SESSION[$key]);
}

function redirect($path){
	header('location: ' . $path);
}

function refresh(){
	header("Refresh:0");
}

//classes
require_once(__DIR__ . '/../php_classes/includes/db.php');
require_once(__DIR__ . '/../php_classes/User.php');
require_once(__DIR__ . '/../php_classes/Administrator.php');
require_once(__DIR__ . '/../php_classes/Cinema.php');
require_once(__DIR__ . '/../php_classes/Section.php');
require_once(__DIR__ . '/../php_classes/Movie.php');
require_once(__DIR__ . '/../php_classes/Hall.php');
require_once(__DIR__ . '/../php_classes/Client.php');
require_once(__DIR__ . '/../php_classes/Registration.php');
require_once(__DIR__ . '/data.php');
