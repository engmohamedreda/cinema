<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	if(!$Cinema->isLoggedIn()) redirect('../');
	if(!$Cinema->status()) redirect('./wait.php');
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Cinema->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							اضافة اعلان جديد
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="./" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
                                    رجوع
                                </a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
					
						<form method="post" enctype="multipart/form-data">
	
							<?php
								if(set('submit')){
									
									$Movie = new Movie();
									
									$name = post('name');
									$description = post('description');
									$photo = files('file');
									$start_date = post('start_date');
									$end_date = post('end_date');
									$times = post('times');
									$section_id = post('section_id');
									$hall_id = post('hall_id');
									$cinema_id = $Cinema->id();
									
									if($Movie->add($name, $description, $photo, $start_date, $end_date, $times, $section_id, $cinema_id, $hall_id)) echo'<div class="alert alert-success"> تم الحفظ بنجاج </div>';
									else echo'<div class="alert alert-danger">'.$Movie->error().'</div>';
									
								}else{
									?>
								<div class="alert alert-info">برجاء ادخال البيانات المطلوبة</div>
									<?php
								}
							?>
							<label>الاسم</label>
							<input type="text" name="name" class="login-input" />
							<div class="split"></div>
							<label>الوصف</label>
							<textarea name="description" class="login-input"></textarea>
							<div class="split"></div>
							<label>صورة</label>
							<input type="file" name="file" class="login-input" />
							<div class="split"></div>
							<label>تاريخ بداية العرض</label>
							<input type="text" name="start_date" class="login-input date" />
							<div class="split"></div>
							<label>تاريخ نهاية العرض</label>
							<input type="text" name="end_date" class="login-input date" />
							<div class="split"></div>
							<label>اوقات العرض</label>
							<hr>
							
							<?php
							
								foreach($movies_times as $time){
									?>
									
										<a href="javascript:void(0)" class="checkbox-label">
											 <?= $time ?> <input class="item" type="checkbox" name="times[]" value="<?= $time ?>">
										</a>
							
									<?php
								}
							
							?>
							
							<div class="split"></div>
							<label>القسم</label>
							<select name="section_id" class="login-input">
								<option value="">حدد القسم</option>
								
								<?php
								
									$section = new Section();
								
									foreach($section->getAll() as $sec) echo '<option value="'.$sec->id().'">'.$sec->name().'</option>';
								
								?>
								
							</select>
							<div class="split"></div>
							<label>قاعة العرض</label>
							<select name="hall_id" class="login-input">
								<option value="">حدد القاعة</option>
								
								<?php
								
									$Hall = new Hall();
								
									foreach($Hall->getAll($Cinema->id()) as $sec) echo '<option value="'.$sec->id().'">'.$sec->name().'</option>';
								
								?>
								
							</select>
							<div class="split"></div>
							<button class="form-submit" type="submit" name="submit">
								حفظ
							</button>
							
						</form>
						
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/bootstrap-datepicker.js"></script>
		<script src="../../js/custom.js"></script>
		
		<script>
		
			$(".checkbox-label").click(function(){
				
				if($(this).find(".item").is(':checked')) $(this).find(".item").attr("checked", false);
				else $(this).find(".item").attr("checked", true);
				
			});
			
			$('.date').datepicker({
				format: "yyyy-mm-dd",
				autoclose: true,
				todayHighlight: true
			});
		
		</script>
		
	</body>
</html>