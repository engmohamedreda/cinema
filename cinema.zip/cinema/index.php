<?php
ob_start();
header('location: android/');