 <?php

class Registration{
	
	private $date = null, $time = null, $movie = null, $cinema = null, $client;
	private $id = 0, $chairs = [], $rating = 0;
	
	private $error;
	
	public function __construct($id = 0, $date = null, $time = null, $chairs = [], $movie = null, $cinema = null, $client = null, $rating = 0){
		$this->id = $id;
		$this->date = $date;
		$this->time = $time;
		$this->movie = $movie;
		$this->chairs = $chairs;
		$this->cinema = $cinema;
		$this->client = $client;
		$this->rating = $rating;
	}
	
	public function add($date, $time, $chairs, $movie, $client){
		
		if(empty($date) || empty($time)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if(!is_array($chairs) || !count($chairs)){
			$this->error = "من فضلك حدد المقاعد";
			return false;
		}
		
		if(!$this->isChairsAvailable($date, $time, $movie, $chairs)) return false;
		
		$Client = new Client();
		$Movie = new Movie();
		
		if(!$Client->getUser($client)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if(!$Movie->get($movie)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if(strtotime($Movie->start_date()) > strtotime($date)){
			$this->error = "الفيلم غير متاح فى ذلك الوقت";
			return false;
		}
		
		if(strtotime($Movie->end_date()) < strtotime($date)){
			$this->error = "الفيلم غير متاح فى ذلك الوقت";
			return false;
		}
		
		if(strtotime(date('Y-m-d')) > strtotime($date)){
			$this->error = "لا يمكن الحجز فى ذلك الموعد";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `registration` where `client_id` = '{$client}' and `movie_id` = '{$movie}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ" . $db->error();
			return false;
		}
		
		if($db->rows()){
			$this->error = "الحجز مسجل مسبقا";
			return false;
		}
		
		$db->sql("INSERT INTO `registration`(`date`, `time`, `movie_id`, `cinema_id`, `client_id`) VALUES('{$date}', '{$time}', '{$movie}', '{$Movie->cinema()->id()}', '{$client}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		$id = $db->id();
		
		foreach($chairs as $chair){
			
			$db->sql("INSERT INTO `registration_chairs`(`location`, `hall_id`, `registration_id`) VALUES('{$chair}', '{$Movie->hall()->id()}', '{$id}')");
			
			if(!$db->execute()){
				$this->error = "خطأ فى التنفيذ" . $db->error();
				$this->remove($id);
				return false;
			}
			
		}
		
		return true;
		
	}
	
	public function get($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `registration` where `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "العنصر غير مسجل";
			return false;
		}
		
		$user = $db->results()[0];
		
		$Cinema = new Cinema();
		$Cinema->getUser($user['cinema_id']);
		
		$client = new client();
		$client->getUser($user['client_id']);
		
		$Movie = new Movie();
		$Movie->get($user['movie_id']);
		
		$this->id = $user['id'];
		$this->date = $user['date'];
		$this->time = $user['time'];
		$this->chairs = $this->getChairs($user['id']);
		$this->movie = $Movie;
		$this->cinema = $Cinema;
		$this->client = $client;
		$this->rating = $user['rating'];
		
		return true;
		
	}
	
	public function getAll(){
		
		$db = new db();
		
		$db->sql("select * from `registration`");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$registrations = [];
		
		foreach($db->results() as $user){
			
			$Cinema = new Cinema();
			$Cinema->getUser($user['cinema_id']);
			
			$client = new client();
			$client->getUser($user['client_id']);
			
			$Movie = new Movie();
			$Movie->get($user['movie_id']);
			
			$registrations[] = new registration($user['id'], $user['date'], $user['time'], $this->getChairs($user['id']), $Movie, $Cinema, $client, $user['rating']);
			
		} 
		
		return $registrations;
		
	}
	
	public function getActive4Cinema($cinema = 0){
		
		$db = new db();
		
		$now = date('Y-m-d');
		
		if($cinema)
			$db->sql("select * from `registration` where `cinema_id` = '{$cinema}' and date(`date`) >= '{$now}'");
		else
			$db->sql("select * from `registration` where  date(`date`) >= '{$now}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$registrations = [];
		
		foreach($db->results() as $user){
			
			$Cinema = new Cinema();
			$Cinema->getUser($user['cinema_id']);
			
			$client = new client();
			$client->getUser($user['client_id']);
			
			$Movie = new Movie();
			$Movie->get($user['movie_id']);
			
			$registrations[] = new registration($user['id'], $user['date'], $user['time'], $this->getChairs($user['id']), $Movie, $Cinema, $client, $user['rating']);
			
		} 
		
		return $registrations;
		
	}
	
	public function getActive4Client($client = 0){
		
		$db = new db();
		
		$now = date('Y-m-d');
		
		if($client)
			$db->sql("select * from `registration` where `client_id` = '{$client}' and date(`date`) >= '{$now}'");
		else
			$db->sql("select * from `registration` where date(`date`) >= '{$now}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$registrations = [];
		
		foreach($db->results() as $user){
			
			$Cinema = new Cinema();
			$Cinema->getUser($user['cinema_id']);
			
			$client = new client();
			$client->getUser($user['client_id']);
			
			$Movie = new Movie();
			$Movie->get($user['movie_id']);
			
			$registrations[] = new registration($user['id'], $user['date'], $user['time'], $this->getChairs($user['id']), $Movie, $Cinema, $client, $user['rating']);
			
		} 
		
		return $registrations;
		
	}
	
	public function getOld4Client($client = 0){
		
		$db = new db();
		
		$now = date('Y-m-d');
		
		if($client)
			$db->sql("select * from `registration` where `client_id` = '{$client}' and date(`date`) < '{$now}'");
		else
			$db->sql("select * from `registration` where date(`date`) < '{$now}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$registrations = [];
		
		foreach($db->results() as $user){
			
			$Cinema = new Cinema();
			$Cinema->getUser($user['cinema_id']);
			
			$client = new client();
			$client->getUser($user['client_id']);
			
			$Movie = new Movie();
			$Movie->get($user['movie_id']);
			
			$registrations[] = new registration($user['id'], $user['date'], $user['time'], $this->getChairs($user['id']), $Movie, $Cinema, $client, $user['rating']);
			
		} 
		
		return $registrations;
		
	}
	
	public function getOld4Cinema($cinema = 0){
		
		$db = new db();
		
		$now = date('Y-m-d');
		
		if($cinema)
			$db->sql("select * from `registration` where `cinema_id` = '{$cinema}' and date(`date`) < '{$now}'");
		else
			$db->sql("select * from `registration` where date(`date`) < '{$now}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$registrations = [];
		
		foreach($db->results() as $user){
			
			$Cinema = new Cinema();
			$Cinema->getUser($user['cinema_id']);
			
			$client = new client();
			$client->getUser($user['client_id']);
			
			$Movie = new Movie();
			$Movie->get($user['movie_id']);
			
			$registrations[] = new registration($user['id'], $user['date'], $user['time'], $this->getChairs($user['id']), $Movie, $Cinema, $client, $user['rating']);
			
		} 
		
		return $registrations;
		
	}
	
	public function getChairs($registration){
		
		$db = new db();
		
		$now = date('Y-m-d');
		
		$db->sql("select * from `registration_chairs` where `registration_id` = '{$registration}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$chairs = [];
		
		foreach($db->results() as $user) $chairs[] = $user['location'];
		
		return $chairs;
		
	}
	
	public function remove($id){
		
		if(!$this->get($id)){
			$this->error = "العنصر غير مسجل";
			return false;
		}
		
		$db = new db();
		
		$db->sql("DELETE FROM `registration` WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function setRating($id, $rating){
		
		if(!is_numeric($rating) || $rating < 1 || $rating > 5){
			$this->error = "التقييم غير صحيح";
			return false;
		}
		
		$db = new db();
		
		if(!$this->get($id)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if($this->rating()){
			$this->error = "لا يمكن القيام بالتقييم مرتين";
			return false;
		}
		
		$db->sql("UPDATE `registration` SET `rating` = '{$rating}' WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function isRegistred($movie, $client){
		
		$Client = new Client();
		$Movie  = new Movie();
		
		$db = new db();
		
		if(!$Client->getUser($client)) return false;
		if(!$Movie->get($movie)) return false;
		
		$db->sql("select * from `registration` where `client_id` = '{$client}' and `movie_id` = '{$movie}'");
		
		if(!$db->execute()) return false;
		
		if($db->rows() != 1) return false;
		
		$this->get($db->results()[0]['id']);
		
		return true;
		
	}
	
	public function isChairsAvailable($date, $time, $movie, $chairs){
		
		$Movie = new Movie();
		
		if(!$Movie->get($movie)){
			$this->error = "الفيلم غير مسجل";
			return false;
		} 
		
		$db = new db();
		
		foreach($chairs as $chair){
			
			$db->sql("select * from `registration_chairs` where `location` = '{$chair}' and `registration_id` in (select `id` from `registration` where `movie_id` = '{$movie}' and `date` = '{$date}' and `time` = '{$time}')");
			
			if(!$db->execute()){
				$this->error = "خطا فى التنفيذ";
				return false;
			} 
			
			if($db->rows()){
				$this->error = "الكرسى رقم";
				$this->error .= " " .  $chair . " " ;
				$this->error .= "غير متاح";
				return false;
			}
		
		}
		
		return true;
		
	}
	
	public function error(){
		return $this->error;
	}
	
	public function id(){
		return $this->id;
	}
	
	public function regdate(){
		return $this->date;
	}
	
	public function regtime(){
		return $this->time;
	}
	
	public function chairs(){
		return $this->chairs;
	}
	
	public function movie(){
		return $this->movie;
	}
	
	public function cinema(){
		return $this->cinema;
	}
	
	public function client(){
		return $this->client;
	}
	
	public function rating(){
		return $this->rating;
	}
	
}

?>