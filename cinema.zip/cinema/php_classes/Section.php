<?php

class Section{
	
	private $name = null;
	private $id = 0, $admin = 0;
	
	private $error;
	
	public function __construct($id = 0, $name = null, $admin = 0){
		$this->id = $id;
		$this->name = $name;
		$this->admin = $admin;
	}
	
	public function add($name, $admin){
		
		if(empty($name)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `section` where `name` = '{$name}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم العنصر مسجل مسبقا";
			return false;
		}
		
		$db->sql("INSERT INTO `section`(`name`, `admin_id`) VALUES('{$name}', '{$admin}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function get($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `section` where `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "العنصر غير مسجل";
			return false;
		}
		
		$user = $db->results()[0];
		
		$admin = new Administrator();
		$admin->getUser($user['admin_id']);
		
		$this->id = $user['id'];
		$this->name = $user['name'];
		$this->admin = $admin;
		
		return true;
		
	}
	
	public function getAll(){
		
		$db = new db();
		
		$db->sql("select * from `section`");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$sections = [];
		
		foreach($db->results() as $user){
			
			$admin = new Administrator();
			$admin->getUser($user['admin_id']);
			
			$sections[] = new Section($user['id'], $user['name'], $admin);
			
		} 
		
		return $sections;
		
	}
	
	public function remove($id){
		
		if(!$this->get($id)){
			$this->error = "العنصر غير مسجل";
			return false;
		}
		
		$db = new db();
		
		$db->sql("DELETE FROM `section` WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function update($id, $name){
		
		if(empty($name)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `section` where `name` = '{$name}' and `id` <> '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم العنصر مسجل مسبقا";
			return false;
		}
	
		$db->sql("UPDATE `section` SET `name` = '{$name}' WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function error(){
		return $this->error;
	}
	
	public function id(){
		return $this->id;
	}
	
	public function name(){
		return $this->name;
	}
	
	public function admin(){
		return $this->admin;
	}
	
}

?>