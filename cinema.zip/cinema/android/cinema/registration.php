<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	if(!$Cinema->isLoggedIn()) redirect('../');
	if(!$Cinema->status()) redirect('./wait.php');
	
	$Registration = new Registration();
	
	if(!set('id') || !$Registration->get(get('id'))) redirect('./');
	$urlLocation = set('backurl') ? get('backurl') : "registrations.php";
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Registration->movie()->name(); ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
		<link href="../../css/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
		
	</head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Registration->movie()->name(); ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="<?= $urlLocation ?>" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
				
						<?php
							
							$showRatingModal = false;
							
							if(strtotime(date('Y-m-d')) > strtotime($Registration->regdate())){
								
								?>
								<label>التقييم</label>
								<br>
								<?php
								
								echo $Registration->rating() > 4 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
								echo $Registration->rating() > 3 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
								echo $Registration->rating() > 2 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
								echo $Registration->rating() > 1 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
								echo $Registration->rating() > 0 ? '<a href="#" class="rate-star-selected"><i class="fa fa-star"></i></a>' : '<a href="#" class="rate-star-white"><i class="fa fa-star"></i></a>'; 
								
								echo '<div class="split"></div>';
																
							}
						
						?>
					
						<label>تاريخ الحجز</label>
						<br>
						<?= $Registration->regdate() ?>
						<div class="split"></div>
					
						<label>وقت الحجز</label>
						<br>
						<?= $Registration->regtime() ?>
						<div class="split"></div>
					
						<label>المقاعد</label>
						<br>
						<?= implode(" - " , $Registration->chairs()) ?>
						<div class="split"></div>
					
						<label>العميل</label>
						<br>
						<a class="info-link" href="client.php?id=<?= $Registration->client()->id() ?>&backurl=registration.php?id=<?= $Registration->id() ?>"><?= $Registration->client()->name() ?></a>
						<div class="split"></div>
					
						<label>الفيلم</label>
						<br>
						<a class="info-link" href="movieDetails.php?id=<?= $Registration->movie()->id() ?>"><?= $Registration->movie()->name() ?></a>
						<div class="split"></div>
					
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
		
		<script>
			
		</script>
		
	</body>
</html>