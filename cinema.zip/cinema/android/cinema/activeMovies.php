<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	if(!$Cinema->isLoggedIn()) redirect('../');
	if(!$Cinema->status()) redirect('./wait.php');
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Cinema->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							الاعلانات السارية
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-sm-12">
								<a href="./" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
                                    رجوع
                                </a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
					
						<form method="get">
							<div class="form-group">
								<input type="text" name="search" class="login-input" placeholder="بحث">
								<button type="submit" class="success-link"><i class="fa fa-search"></i>بحث</button>
							</div>
						</form>
						<hr>
						<?php
						
							$Movie = new Movie();
						
							foreach($Movie->getActive($Cinema->id()) as $user){
								if(set('search') && !empty(get('search')) && strpos($user->name(), get('search')) === false) continue;
								echo '<a href="movieDetails.php?id='.$user->id().'" class="panel-link">
										'. $user->name() .'
									</a>';
							}
						
						?>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
	</body>
</html>