<?php
	require_once('../../php_includes/controller.php');
	$Administrator = new Administrator();
	$Administrator->logout();
	redirect('../');