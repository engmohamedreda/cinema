<?php

interface User{
	
	public function login($username, $password);
	
	public function isLoggedIn();
	
	public function logout();
	
	public function error();
	
	public function id();
	
	public function setid($id);
	
}

?>