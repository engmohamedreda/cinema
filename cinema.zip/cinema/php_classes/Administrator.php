<?php

class Administrator implements User{
	
	private $username = null, $password = null;
	private $id = 0;
	
	private $error;
	
	public function __construct($id = 0, $username = null, $password = null){
		$this->id = $id;
		$this->username = $username;
		$this->password = $password;
	}
	
	public function addUser($username, $password, $passwordConf){
		
		if(empty($username) || empty($password)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if($password != $passwordConf){
			$this->error = "كلمة السر غير متطابقة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `admin` where `username` = '{$username}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم المستخدم مسجل مسبقا";
			return false;
		}
		
		$db->sql("INSERT INTO `admin`(`username`, `password`) VALUES('{$username}', '{$password}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function getUser($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `admin` where `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$user = $db->results()[0];
		
		$this->id = $user['id'];
		$this->username = $user['username'];
		$this->password = $user['password'];
		
		return true;
		
	}
	
	public function getUsers(){
		
		$db = new db();
		
		$db->sql("select * from `admin`");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$users = [];
		
		foreach($db->results() as $user) $users[] = new Administrator($user['id'], $user['username'], $user['password']);
		
		return $users;
		
	}
	
	public function removeUser($id){
		
		if(!$this->getUser($id)){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$db = new db();
		
		$db->sql("DELETE FROM `admin` WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function updateUser($id, $username, $password, $passwordConf){
		
		if(empty($username)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		if(!empty($password)){
				
			if($password != $passwordConf){
				$this->error = "كلمة السر غير متطابقة";
				return false;
			}
			
			$db->sql("UPDATE `admin` SET `password` = '{$password}' WHERE `id` = '{$id}'");
			
			if(!$db->execute()){
				$this->error = "خطأ فى التنفيذ";
				return false;
			}
			
		}
		
		$db->sql("select * from `admin` where `username` = '{$username}' and `id` <> '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم المستخدم مسجل مسبقا";
			return false;
		}
	
		$db->sql("UPDATE `admin` SET `username` = '{$username}' WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function login($username, $password){
		
		if(empty($username) || empty($password)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `admin` where `username` = '{$username}' and `password` = '{$password}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ" . $db->error();
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$id = $db->results()[0]['id'];
		
		sign('admin', $id);
		
		return true;
		
	}
	
	public function isLoggedIn(){
		 return is_signed('admin') && $this->getUser(signed('admin'));
	}
	
	public function logout(){
		removeSign('admin');
	}
	
	public function setid($id){
		$this->id = $id;
	}
	
	public function error(){
		return $this->error;
	}
	
	public function id(){
		return $this->id;
	}
	
	public function username(){
		return $this->username;
	}
	
	public function password(){
		return $this->password;
	}
	
}

?>