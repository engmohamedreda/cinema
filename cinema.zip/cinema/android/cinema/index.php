<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	if(!$Cinema->isLoggedIn()) redirect('../');
	if(!$Cinema->status()) redirect('./wait.php');
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Cinema->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							لوحة التحكم
						</div>
					</div>
					<div class="col-md-12 login-box">
						<a href="halls.php" class="panel-link">
							القاعات
						</a>
						<a href="newMovie.php" class="panel-link">
							اضافة اعلان جديد
						</a>
						<a href="activeMovies.php" class="panel-link">
							الاعلانات السارية
						</a>
						<a href="waitingList.php" class="panel-link">
							اعلانات فى انتظار الموافقة
						</a>
						<a href="oldMovies.php" class="panel-link">
							الاعلانات المنتهية
						</a>
						<a href="registrations.php" class="panel-link">
							الحجوزات
						</a>
						<a href="oldRegistrations.php" class="panel-link">
							الحجوزات القديمة
						</a>
						<a href="clients.php" class="panel-link">
							العملاء
						</a>
					</div>
					<div class="col-md-12 externals">
						<a href="my.php" class="success-link">
							البيانات الشخصية
						</a>
						<a href="out.php" class="danger-link">
							تسجيل خروج
						</a>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
	</body>
</html>