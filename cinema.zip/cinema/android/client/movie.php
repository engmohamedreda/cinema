<?php
	require_once('../../php_includes/controller.php');
	$Client = new Client();
	if(!$Client->isLoggedIn()) redirect('../');
	
	$Movie = new Movie();
	
	if(!set('id') || !$Movie->get(get('id'))) redirect('./');
	
	$back = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "./";
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Movie->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Movie->name() ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="<?= $back ?>" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
				
						<label>الاسم</label>
						<br>
						<?= $Movie->name() ?>
						<div class="split"></div>
					
						<label>الوصف</label>
						<br>
						<?= $Movie->description() ?>
						<div class="split"></div>
					
						<label>تاريخ بداية العرض</label>
						<br>
						<?= $Movie->start_date() ?>
						<div class="split"></div>
					
						<label>تاريخ نهاية العرض</label>
						<br>
						<?= $Movie->end_date() ?>
						<div class="split"></div>
					
						<label>اوقات العرض</label>
						<br>
						<?php
							foreach($Movie->times() as $time) echo $time . ' <br>';
						?>
						<div class="split"></div>
					
						<label>القاعة</label>
						<br>
						<?= $Movie->hall()->name() ?>
						<div class="split"></div>
					
						<label>القسم</label>
						<br>
						<?= $Movie->section()->name() ?>
						<div class="split"></div>
					
						<label>السينما</label>
						<br>
						<?= $Movie->cinema()->name() ?>
						<div class="split"></div>
					
						<label>صورة العرض</label>
						<br>
						<img src="../../uploads/<?= $Movie->photo() ?>" style="max-width: 500px; width: 90%;">
						<div class="split"></div>
					
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<?php
									$Registration = new Registration();
									$disabled = "";
									if($Registration->isRegistred($Movie->id(),$Client->id())) $disabled = "disabled";
								?>
								<button id="successAction" class="success-link" <?= $disabled ?>>
									حجز
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/datepicker.js"></script>
		<script src="../../js/custom.js"></script>
		
		<script>
			
			<?php
				if(empty($disabled)){
			?>
			
			$("#successAction").click(function(){
				window.location = "setRegistration.php?id=<?= $Movie->id() ?>";
			});
			
			<?php 
			} 
			?>
			
		</script>
		
	</body>
</html>