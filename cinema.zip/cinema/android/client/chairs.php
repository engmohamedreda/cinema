<?php
	
	require_once('../../php_includes/controller.php');
	$Client = new Client();
	if(!$Client->isLoggedIn()) redirect('../');
	
	$Movie = new Movie();
	
	if(!set('movie') || !set('date') || !set('time') || !$Movie->get(post('movie'))) return;
	
	$chairs = $Movie->getChairsList(post('movie'), post('date'), post('time'));
	
	echo '<hr><label class="">حدد المقاعد</label>';
	
	foreach($chairs as $row => $columns){
		
		?>
		
<div class="chairs-row">
	
	<a class="main" href="javascript:void(0)">
		<?= $row ?>
	</a>
	
		<?php
		
		foreach($columns as $column){
			
			$location = $column['location'];
			$status = $column['status'] ? "available" : "not-available";
			
			if($column['status']){
				
			?>
	
	<button class="chair available" type="button" onClick="setOn('<?= $location ?>')" id="chair-<?= $location ?>">
		<?= $location ?>
	</button>
	
			<?php
			
			}else{
				
			?>
	
	<button class="chair not-available" type="button" disabled>
		<?= $location ?>
	</button>
	
			<?php
			
			}
			
		}
		
		?>
		
</div>
		
		<?php
		
	}
	
?>
