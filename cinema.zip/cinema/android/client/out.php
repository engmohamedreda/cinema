<?php
	require_once('../../php_includes/controller.php');
	$Client = new Client();
	$Client->logout();
	redirect('../');