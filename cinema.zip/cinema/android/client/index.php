<?php
	require_once('../../php_includes/controller.php');
	$Client = new Client();
	if(!$Client->isLoggedIn()) redirect('../');
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Client->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							لوحة التحكم
						</div>
					</div>
					<div class="col-md-12 login-box">
						<a href="movies.php" class="panel-link">
							الافلام
						</a>
						<a href="cinemasByLocation.php" class="panel-link">
							سينمات قريبة منك
						</a>
						<a href="cinemas.php" class="panel-link">
							السينمات
						</a>
						<a href="registrations.php" class="panel-link">
							الحجوزات
						</a>
						<a href="oldRegistrations.php" class="panel-link">
							الحجوزات السابقة
						</a>
						<a href="oldCinemas.php" class="panel-link">
							سينمات قمت بالحجز فيها
						</a>
					</div>
					<div class="col-md-12 externals">
						<a href="my.php" class="success-link">
							البيانات الشخصية
						</a>
						<a href="out.php" class="danger-link">
							تسجيل خروج
						</a>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
	</body>
</html>