<?php
	require_once('../../php_includes/controller.php');
	$Client = new Client();
	if(!$Client->isLoggedIn()) redirect('../');
	
	$Movie = new Movie();
	
	if(!set('id') || !$Movie->get(get('id'))) redirect('./');
	
	$back = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : "./";

	$Registration = new Registration();
	$disabled = "";
	if($Registration->isRegistred($Movie->id(),$Client->id())) redirect('registration.php?id=' . $Registration->id());
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Movie->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Movie->name() ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="movie.php?id=<?= $Movie->id() ?>" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
				
						<label>الفيلم</label>
						<br>
						<?= $Movie->name() ?>
						<div class="split"></div>
					
						<form action="javascript:void(0)">
							<div class="row">
								<div class="col-md-12 text-right" id="message">
									حجز
									<hr>
									
								</div>
								<div class="col-12 text-right">
									<label>التاريخ</label>
									<input type="text" name="date" onChange="chairsReset()" class="login-input-dark date" id="dateIn" value="<?= date('Y-m-d') ?>"/>
								</div>
								<div class="col-12 text-right">
									<label>الوقت</label>
									<select class="login-input-dark" onChange="chairsReset()" name="time" id="timeIn">
										<?php
											foreach($Movie->times() as $time) echo '<option value="'.$time.'">'.$time.'</option>';
										?>
									</select>
								</div>
								<div class="col-12 text-right">
									<hr>
									<button type="button" id="showChairs" class="btn btn-info">عرض المقاعد</button>
								</div>
								<div class="col-12 text-right">
									<div id="chairs-in">
									</div>
								</div>
								<div class="col-12 text-right">
									<button type="button" id="registration" class="success-link">حجز</button>
								</div>
							</div>
						</form>
						
					</div>
					
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/datepicker.js"></script>
		<script src="../../js/custom.js"></script>
		
		<script>
			
			 var chairs = [];
			 
			 function chairsReset(){
				showChairs();
			 }
			
			$("#registration").click(function(){
				
				var time = $("#timeIn").val();
				var date = $("#dateIn").val();
				
				$("#showChairs").attr("disabled", true);
				$("#registration").attr("disabled", true);
			
				if(chairs.length == 0){
					$("#registration").attr("disabled", false);
					$("#showChairs").attr("disabled", false);
					$("#message").html('<div class="alert alert-danger" role="alert"> من فضلك حدد المقاعد </div>');
					return;
				}
			
				$.ajax({
					
					type: "POST",
					url: "saveRegistration.php",
					data: {
						"time" : time,
						"date" : date,
						"movie" : "<?= $Movie->id() ?>",
						"chairs" : chairs
					},
					success: function(results){
						$("#registration").attr("disabled", false);
						$("#showChairs").attr("disabled", false);
						$("#message").html(results);
						$('html, body').animate({ scrollTop: 0 }, 'fast');
					},error: function(){
						$("#message").html('<div class="alert alert-danger" role="alert"> لا يوجد اتصال بالانترنت </div>');
						$("#registration").attr("disabled", false);
						$("#showChairs").attr("disabled", false);
						$('html, body').animate({ scrollTop: 0 }, 'fast');
					}
				
				});
			   
			});
			
			
			$("#showChairs").click(function(){
				showChairs();
			});
			
			function showChairs(){
				
				var time = $("#timeIn").val();
				var date = $("#dateIn").val();
				
				$("#showChairs").attr("disabled", true);
				$("#registration").attr("disabled", true);
			
				chairs = [];
				
				$.ajax({
					
					type: "POST",
					url: "chairs.php",
					data: {
						"time" : time,
						"date" : date,
						"movie" : "<?= $Movie->id() ?>"
					},
					success: function(results){
						$("#chairs-in").html(results);
						$("#showChairs").attr("disabled", false);
						$("#registration").attr("disabled", false);
					},error: function(){
						$("#chairs-in").html('<div class="alert alert-danger" role="alert"> لا يوجد اتصال بالانترنت </div>');
						$("#showChairs").attr("disabled", false);
						$("#registration").attr("disabled", false);
					}
				
				});
			   
			}
			
			$(".date").datepicker({
				format: 'yyyy-mm-dd'
			});

			function setOn(location){
				if(chairs.includes(location)){
					chairs.splice(chairs.indexOf(location), 1)
					$("#chair-"+location).removeClass("selected");
				}else{
					chairs.push(location);
					$("#chair-"+location).addClass("selected");
				}
			}

		</script>
		
	</body>
</html>