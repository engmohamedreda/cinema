<?php
	require_once('../../php_includes/controller.php');
	$Client = new Client();
	if(!$Client->isLoggedIn()) redirect('../');
	
	$Cinema = new Cinema();
	
	if(!set('id') || !$Cinema->getUser(get('id'))) redirect('./');
	$urlLocation = set('backurl') ? get('backurl') : "cinemas.php";
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Cinema->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Cinema->name() ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="<?= $urlLocation ?>" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
							<div class="col-12">
								<a href="movies.php?cinema=<?= $Cinema->id() ?>&backurl=cinema.php?id=<?= $Cinema->id() ?>" class="success-link">
									الافلام المعروضة
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
				
						<label>الاسم</label>
						<br>
						<?= $Cinema->name() ?>
						<div class="split"></div>
					
						<label>البريد الالكترونى</label>
						<br>
						<?= $Cinema->email() ?>
						<div class="split"></div>
					
						<label>رقم الهاتف</label>
						<br>
						<?= $Cinema->phone() ?>
						<div class="split"></div>
					
						<label>الوصف</label>
						<br>
						<?= $Cinema->description() ?>
						<div class="split"></div>
					
						<label>البلد</label>
						<br>
						<?= $Cinema->country() ?>
						<div class="split"></div>
					
						<label>المحافظة</label>
						<br>
						<?= $Cinema->governorate() ?>
						<div class="split"></div>
					
						<label>المنطقة</label>
						<br>
						<?= $Cinema->region() ?>
						<div class="split"></div>
					
						<label>الصورة</label>
						<br>
						<img src="../../uploads/<?= $Cinema->picture() ?>" style="max-width: 500px; width: 90%;">
						<div class="split"></div>
					
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
		
		<div class="modal" id="deleteMessage" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-footer">
						<div class="row">
							<div class="col-md-12 text-right">
								هل انت متاكد من الحذف
								<hr>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="danger-link" data-dismiss="modal">لا</button>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="success-link" id="deleteYes">نعم</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="modal" id="successMessage" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-footer">
						<div class="row">
							<div class="col-md-12 text-right">
								تفعيل الحساب
								<hr>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="danger-link" data-dismiss="modal">لا</button>
							</div>
							<div class="col-6 text-right">
								<button type="button" class="success-link" id="activate">نعم</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
			
			$("#successAction").click(function(){
				$("#successMessage").modal("show");
			});
		
			$("#deleteAction").click(function(){
				$("#deleteMessage").modal("show");
			});
		
			$("#deleteYes").click(function(){
				window.location = "<?= $_SERVER['PHP_SELF'] ?>?id=<?=get('id')?>&delete=yes";
			});
		
			$("#activate").click(function(){
				window.location = "<?= $_SERVER['PHP_SELF'] ?>?id=<?=get('id')?>&activate=yes";
			});
		
		</script>
		
	</body>
</html>