<?php

$movies_times = [];

$movies_times[] = "1 مساء";
$movies_times[] = "2 مساء";
$movies_times[] = "3 مساء";
$movies_times[] = "4 مساء";
$movies_times[] = "5 مساء";
$movies_times[] = "6 مساء";
$movies_times[] = "7 مساء";
$movies_times[] = "8 مساء";
$movies_times[] = "9 مساء";
$movies_times[] = "10 مساء";
$movies_times[] = "11 مساء";
$movies_times[] = "12 مساء";
$movies_times[] = "1 صباحا";
$movies_times[] = "2 صباحا";
$movies_times[] = "3 صباحا";

$movies_times = array_reverse($movies_times);

$governorates = [];

$governorates[] = "القاهرة";
$governorates[] = "الإسكندرية";
$governorates[] = "أسيوط";
$governorates[] = "أسوان";
$governorates[] = "البحيرة";
$governorates[] = "بني سويف";
$governorates[] = "الدقهلية";
$governorates[] = "الجيزة";
$governorates[] = "دمياط";
$governorates[] = "الفيوم";
$governorates[] = "الغربية";
$governorates[] = "الإسماعيلية";
$governorates[] = "كفر الشيخ";
$governorates[] = "مطروح";
$governorates[] = "المنيا";
$governorates[] = "شمال سيناء";
$governorates[] = "المنوفية";
$governorates[] = "الوادي الجديد";
$governorates[] = "بورسعيد";
$governorates[] = "القليوبية";
$governorates[] = "قنا";
$governorates[] = "البحر الأحمر";
$governorates[] = "الشرقية";
$governorates[] = "سوهاج";
$governorates[] = "جنوب سيناء";
$governorates[] = "السويس";
$governorates[] = "الأقصر";
