<?php

class Client implements User{
	
	private $name = null, $email = null, $phone = null,
			$country = null, $governorate = null, $password = null, $region = null,
			$picture = null;
	
	private $id = 0;
	
	private $error;
	
	public function __construct($id = 0, $name = null, $email = null, $phone = null,
			$country = null, $governorate = null, $region = null,
			$picture = null, $password = null){
		$this->id = $id;
		$this->name = $name;
		$this->email = $email;
		$this->phone = $phone;
		$this->country = $country;
		$this->governorate = $governorate;
		$this->region = $region;
		$this->password = $password;
		$this->picture = $picture;
	}
	
	public function addUser($name, $email, $phone, $country, $governorate, $region, $picture, $passwordConf, $password){
		
		if(empty($email) || empty($name) || empty($country) ||
			empty($governorate) || empty($region) || empty($password) || empty($picture)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if($password != $passwordConf){
			$this->error = "كلمة السر غير متطابقة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `client` where `email` = '{$email}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم المستخدم مسجل مسبقا";
			return false;
		}
		
		$rand = rand();
		
		$pictureExtension = "." . pathinfo($picture['name'], PATHINFO_EXTENSION);
		$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
		
		while(file_exists($picturePath)){
			$rand = rand();
			$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
		}
		
		if(!@move_uploaded_file($picture['tmp_name'], $picturePath)){
			$this->error = "خطأ فى تحميل الملف";
			return false;
		}
		
		$picture = $rand . $pictureExtension;
		
		$db->sql("INSERT INTO `client`(`name`, `email`, `phone`, `country`, `governorate`, `region`, `picture`, `password`)".
					" VALUES('{$name}', '{$email}', '{$phone}', '{$country}', '{$governorate}', '{$region}', '{$picture}', '{$password}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function getUser($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `client` where `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$user = $db->results()[0];
		
		$this->id = $user['id'];
		$this->name = $user['name'];
		$this->email = $user['email'];
		$this->phone = $user['phone'];
		$this->country = $user['country'];
		$this->governorate = $user['governorate'];
		$this->region = $user['region'];
		$this->picture = $user['picture'];
		$this->password = $user['password'];
		
		return true;
		
	}
	
	public function getUsers(){
		
		$db = new db();
		
		$db->sql("select * from `client`");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$users = [];
		foreach($db->results() as $user) 
			$users[] = new client(
									$user['id'],
									$user['name'],
									$user['email'],
									$user['phone'],
									$user['country'],
									$user['governorate'],
									$user['region'],
									$user['picture'],
									$user['password']
								);
		
		return $users;
		
	}
	
	public function getCinemaClients($cinema){
		
		$db = new db();
		
		$db->sql("select * from `client` where `id` in (select `client_id` from `registration` where `cinema_id` = '{$cinema}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$users = [];
		foreach($db->results() as $user) 
			$users[] = new client(
									$user['id'],
									$user['name'],
									$user['email'],
									$user['phone'],
									$user['country'],
									$user['governorate'],
									$user['region'],
									$user['picture'],
									$user['password']
								);
		
		return $users;
		
	}
	
	public function removeUser($id){
		
		if(!$this->getUser($id)){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
	
		$db = new db();
		
		$db->sql("DELETE FROM `client` WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		@unlink( __DIR__ ."/../uploads/" . $this->picture);
		
		return true;
		
	}
	
	public function updateUser($id, $name, $email, $phone, $country, $governorate, $region, $picture, $passwordConf, $password){
		
		if(empty($email) || empty($name) || empty($country) ||
			empty($governorate) || empty($region)){
			$this->error = "من فضلك ادخل البيانات المطلوبة2";
			return false;
		}
		
		if(!$this->getUser($id)){
			$this->error = "من فضلك ادخل البيانات المطلوبة1";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `client` where `email` = '{$email}' AND `id` <> '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم المستخدم مسجل مسبقا";
			return false;
		}
		
		if(!empty($password)){
				
			if($password != $passwordConf){
				$this->error = "كلمة السر غير متطابقة";
				return false;
			}
			
			$db->sql("UPDATE `client` SET `password` = '{$password}' WHERE `id` = '{$id}'");
			
			if(!$db->execute()){
				$this->error = "خطأ فى التنفيذ";
				return false;
			}
			
		}
		
		if(!empty($picture)){
			
			$rand = rand();
			
			$pictureExtension = "." . pathinfo($picture['name'], PATHINFO_EXTENSION);
			$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
			
			
			while(file_exists($picturePath)){
				$rand = rand();
				$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
			}
			
			$old = "/../uploads/" . $this->picture;
			
			if(!@move_uploaded_file($picture['tmp_name'], $picturePath)){
				$this->error = "خطأ فى تحميل الملف";
				return false;
			}
			
			@unlink( __DIR__ . $old);
			
			$picture = $rand . $pictureExtension;
		
			$db->sql("UPDATE `client` SET `picture` = '{$picture}' WHERE `id` = '{$id}'");
			
			if(!$db->execute()){
				$this->error = "خطأ فى التنفيذ";
				return false;
			}
			
		}
		
		$db->sql("UPDATE `client` SET `name` = '{$name}',`email` = '{$email}',`phone` = '{$phone}',`country` = '{$country}',`governorate` = '{$governorate}',`region` = '{$region}' WHERE `id` = '{$id}'");
			
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function login($email, $password){
		
		if(empty($email) || empty($password)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `client` where `email` = '{$email}' and `password` = '{$password}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ" . $db->error();
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$id = $db->results()[0]['id'];
		
		sign('client', $id);
		
		return true;
		
	}
	
	public function isLoggedIn(){
		 return is_signed('client') && $this->getUser(signed('client'));
	}
	
	public function logout(){
		removeSign('client');
	}
	
	public function setid($id){
		$this->id = $id;
	}
	
	public function error(){
		return $this->error;
	}
	
	public function id(){
		return $this->id;
	}
	
	public function name(){
		return $this->name;
	}
	
	public function email(){
		return $this->email;
	}
	
	public function phone(){
		return $this->phone;
	}
	
	public function description(){
		return $this->description;
	}
	
	public function country(){
		return $this->country;
	}
	
	public function governorate(){
		return $this->governorate;
	}
	
	public function picture(){
		return $this->picture;
	}
	
	public function region(){
		return $this->region;
	}
	
	public function password(){
		return $this->password;
	}
	
	public function status(){
		return $this->status;
	}
	
}

?>