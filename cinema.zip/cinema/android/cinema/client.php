<?php
	require_once('../../php_includes/controller.php');
	$Cinema = new Cinema();
	if(!$Cinema->isLoggedIn()) redirect('../');
	if(!$Cinema->status()) redirect('./wait.php');
	
	$Client = new Client();
	
	if(!set('id') || !$Client->getUser(get('id'))) redirect('./');
	$urlLocation = set('backurl') ? get('backurl') : "cinemas.php";
	
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Client->name() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							<?= $Client->name() ?>
						</div>
					</div>
					<div class="col-md-12 externals">
						<div class="row">
							<div class="col-12">
								<a href="<?= $urlLocation ?>" class="danger-link">
                                    <i class="fa fa-arrow-left"></i>
									رجوع
								</a>
							</div>
						</div>
					</div>
					<div class="col-md-12 login-box">
				
						<label>الاسم</label>
						<br>
						<?= $Client->name() ?>
						<div class="split"></div>
					
						<label>البريد الالكترونى</label>
						<br>
						<?= $Client->email() ?>
						<div class="split"></div>
					
						<label>رقم الهاتف</label>
						<br>
						<?= $Client->phone() ?>
						<div class="split"></div>
					
						<label>الصورة</label>
						<br>
						<img src="../../uploads/<?= $Client->picture() ?>" style="max-width: 500px; width: 90%;">
						<div class="split"></div>
					
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
		
	</body>
</html>