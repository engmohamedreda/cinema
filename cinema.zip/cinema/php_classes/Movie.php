<?php

class Movie{
	 	
	private $name = null, $description = null, $photo = null, $start_date = null,
			$end_date = null, $times = [], $section = null,
			$cinema = null, $hall = null;
			
	private $status = 0;
			
	private $id = 0;
	
	private $error;
	
	public function __construct($id = 0, $name = null, $description = null, $photo = null, $start_date = null,
			$end_date = null, $times = [],
			$section = null, $cinema = null, $hall = null, $status = 0){
		$this->id = $id;
		$this->name = $name;
		$this->description = $description;
		$this->photo = $photo;
		$this->start_date = $start_date;
		$this->end_date = $end_date;
		$this->times = $times;
		$this->section = $section;
		$this->cinema = $cinema;
		$this->hall = $hall;
		$this->status = $status;
	}
	
	public function add($name, $description, $photo, $start_date, $end_date, $times, $section_id, $cinema_id, $hall_id){
		
		$Cinema = new Cinema();
		$Section = new Section();
		$Hall = new Hall();
		
		if(empty($name) || empty($description) || empty($photo) ||
			empty($start_date) || empty($end_date) || empty($times) || !is_array($times)
			|| !$Cinema->getUser($cinema_id) || !$Section->get($section_id) || !$Hall->get($hall_id)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if(strtotime($start_date) < ( time() - (24*24*60) )){
			$this->error = "وقت البداية غير صحيح";
			return false;
		}
		
		if(strtotime($start_date) > strtotime($end_date)){
			$this->error = "وقت البداية بعد وقت النهاية";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `movie` where `name` = '{$name}' AND `cinema_id` = '{$cinema_id}' AND DATE(`end_date`) > '{$start_date}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "العنصر مسجل مسبقا";
			return false;
		}
		
		$rand = rand();
		
		$pictureExtension = "." . pathinfo($photo['name'], PATHINFO_EXTENSION);
		$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
		
		
		while(file_exists($picturePath)){
			$rand = rand();
			$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
		}
		
		if(!@move_uploaded_file($photo['tmp_name'], $picturePath)){
			$this->error = "خطأ فى تحميل الملف";
			return false;
		}
		
		$photo = $rand . $pictureExtension;
		
		$times = serialize($times);
		
		$db->sql("INSERT INTO `movie`(`name`, `description`, `photo`, `start_date`, `end_date`, `times`, `section_id`, `cinema_id`, `hall_id`)".
					" VALUES('{$name}', '{$description}', '{$photo}', '{$start_date}', '{$end_date}', '{$times}', '{$section_id}', '{$cinema_id}', '{$hall_id}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function update($id, $name, $description, $photo, $times){
		
		if(empty($name) || empty($description) ||
			empty($times) || !is_array($times)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if(!$this->get($id)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `movie` where `name` = '{$name}' AND `cinema_id` = '{$this->cinema()->id()}' AND DATE(`end_date`) > '{$this->start_date()}' AND `id` <> '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم المستخدم مسجل مسبقا";
			return false;
		}
		
		if(!empty($photo) && isset($photo['tmp_name']) && !empty($photo['tmp_name'])){
			
			$rand = rand();
			
			$pictureExtension = "." . pathinfo($photo['name'], PATHINFO_EXTENSION);
			$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
			
			
			while(file_exists($picturePath)){
				$rand = rand();
				$picturePath = __DIR__ . "/../uploads/" . $rand . $pictureExtension;
			}
			
			$old = "/../uploads/" . $this->photo;
			
			if(!@move_uploaded_file($photo['tmp_name'], $picturePath)){
				$this->error = "خطأ فى تحميل الملف";
				return false;
			}
			
			@unlink($old);
			
			$photo = $rand . $pictureExtension;
		
			$db->sql("UPDATE `movie` SET `photo` = '{$photo}' WHERE `id` = '{$id}'");
			
			if(!$db->execute()){
				$this->error = "خطأ فى التنفيذ";
				return false;
			}
			
		}
		
		$times = serialize($times);
		
		$db->sql("UPDATE `movie` SET `name` = '{$name}',`description` = '{$description}',`times` = '{$times}' WHERE `id` = '{$id}'");
			
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function get($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `movie` where `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$data = $db->results()[0];
		
		$section = new Section();
		$cinema = new Cinema();
		$hall = new Hall();
		$section->get($data['section_id']);
		$cinema->getUser($data['cinema_id']);
		$hall->get($data['hall_id']);
		
		$this->id = $data['id'];
		$this->name = $data['name'];
		$this->description = $data['description'];
		$this->photo = $data['photo'];
		$this->start_date = $data['start_date'];
		$this->end_date = $data['end_date'];
		$this->times = $data['times'];
		$this->section = $section;
		$this->cinema = $cinema;
		$this->hall = $hall;
		$this->status = $data['status'];
		
		return true;
		
	}
	
	public function getAll($cinema = 0){
		
		$db = new db();
		
		if($cinema)
			$db->sql("select * from `movie` where `cinema_id` = '{$cinema}'");
		else
			$db->sql("select * from `movie`");
			
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$all = [];
		
		foreach($db->results() as $data){
			
			$section = new Section();
			$cinema = new Cinema();
			$hall = new Hall();
			$section->get($data['section_id']);
			$hall->get($data['hall_id']);
			$cinema->getUser($data['cinema_id']);
			
			$all[] = new Movie(
									$data['id'],
									$data['name'],
									$data['description'],
									$data['photo'],
									$data['start_date'],
									$data['end_date'],
									$data['times'],
									$section,
									$cinema,
									$hall,
									$data['status']
								);
		
		}
		
		return $all;
		
	}
	
	public function getActive($cinema = 0){
		
		$db = new db();
		
		$now = date('Y-m-d');
		
		if($cinema)
			$db->sql("select * from `movie` where `status` = '1' AND date(`end_date`) >= '{$now}' and `cinema_id` = '{$cinema}'");
		else
			$db->sql("select * from `movie` where `status` = '1' AND date(`end_date`) >= '{$now}'");
			
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$all = [];
		
		foreach($db->results() as $data){
			
			$section = new Section();
			$Cinema = new Cinema();
			$section->get($data['section_id']);
			$Cinema->getUser($data['cinema_id']);
			
			$all[] = new Movie(
									$data['id'],
									$data['name'],
									$data['description'],
									$data['photo'],
									$data['start_date'],
									$data['end_date'],
									$data['times'],
									$section,
									$Cinema,
									$data['status']
								);
		
		}
		
		return $all;
		
	}
	
	public function getOld($cinema = 0){
		
		$db = new db();
		
		$now = date('Y-m-d');
		
		if($cinema)
			$db->sql("select * from `movie` where `status` = '1' AND date(`end_date`) < '{$now}' and `cinema_id` = '{$cinema}'");
		else
			$db->sql("select * from `movie` where `status` = '1' AND date(`end_date`) < '{$now}'");
			
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$all = [];
		
		foreach($db->results() as $data){
			
			$section = new Section();
			$Cinema = new Cinema();
			$section->get($data['section_id']);
			$Cinema->getUser($data['cinema_id']);
			
			$all[] = new Movie(
									$data['id'],
									$data['name'],
									$data['description'],
									$data['photo'],
									$data['start_date'],
									$data['end_date'],
									$data['times'],
									$section,
									$Cinema,
									$data['status']
								);
		
		}
		
		return $all;
		
	}
	
	public function getNew($cinema = 0){
		
		$db = new db();
		
		if($cinema)
			$db->sql("select * from `movie` where `status` = '0' and `cinema_id` = '{$cinema}'");
		else
			$db->sql("select * from `movie` where `status` = '0'");
			
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$all = [];
		
		foreach($db->results() as $data){
			
			$section = new Section();
			$Cinema = new Cinema();
			$section->get($data['section_id']);
			$Cinema->getUser($data['cinema_id']);
			
			$all[] = new Movie(
									$data['id'],
									$data['name'],
									$data['description'],
									$data['photo'],
									$data['start_date'],
									$data['end_date'],
									$data['times'],
									$section,
									$Cinema,
									$data['status']
								);
		
		}
		
		return $all;
		
	}
	
	public function getRating($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `registration` where `movie_id` = '{$id}' and `rating` <> '0'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return 0;
		}
		
		$rating = 0;
		$users = 0;
		
		foreach($db->Results() as $result){
			$rating += $result['rating'];
			$users++;
		}
		
		return $rating && $users ? ($rating / $users) : 0;
		
	}
	
	public function remove($id){
		
		if(!$this->get($id)){
			$this->error = "العنصر غير مسجل";
			return false;
		}
	
		$db = new db();
		
		$db->sql("DELETE FROM `movie` WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		@unlink("/../uploads/" . $this->photo());
		
		return true;
		
	}
	
	public function activate($id){
		
		if(!$this->get($id)){
			$this->error = "المستخدم غير مسجل";
			return false;
		}
		
		$db = new db();
		
		$db->sql("UPDATE `movie` SET `status` = '1' WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function getChairsList($movie, $date, $time){
		
		if(!$this->get($movie)) return [];
		
		$db = new db();
		
		$db->sql("select * from `registration_chairs` where `registration_id` in (select `id` from `registration` where `movie_id` = '{$movie}' and `date` = '{$date}' and `time` = '{$time}')");
		
		if(!$db->execute()) return [];
		
		$registred = [];
		
		foreach($db->results() as $chair) $registred[] = $chair["location"];
		
		$allChairs = [];
		
		$alphas = range('A', 'Z');
	
		for($i = 0; $i < $this->hall->rows(); $i++){
			for($x = 1; $x <= $this->hall->columns(); $x++){
				$location = $alphas[$i] . $x;
				$status = !in_array($location, $registred);
				$allChairs[$alphas[$i]][] = ["location" => $location, "status" => $status];
			}
		}
		
		return $allChairs;
		
	}
	
	public function setid($id){
		$this->id = $id;
	}
	
	public function error(){
		return $this->error;
	}
	
	public function id(){
		return $this->id;
	}
	
	public function name(){
		return $this->name;
	}
	
	public function description(){
		return $this->description;
	}
	
	public function photo(){
		return $this->photo;
	}
	
	public function start_date(){
		return $this->start_date;
	}
	
	public function end_date(){
		return $this->end_date;
	}
	
	public function times(){
		return @unserialize($this->times);
	}
	
	public function section(){
		return $this->section;
	}
	
	public function cinema(){
		return $this->cinema;
	}
	
	public function hall(){
		return $this->hall;
	}
	
	public function status(){
		return $this->status;
	}
	
}

?>