<?php
	require_once('../../php_includes/controller.php');
	$Administrator = new Administrator();
	if(!$Administrator->isLoggedIn()) redirect('../');
?>
<!DOCTYPE html>
<html>
	<head>
	
		<title><?= $Administrator->username() ?></title>
		
		<meta charset="utf-8">
		
		<link href="../../css/bootstrap.css" rel="stylesheet" type="text/css">
		<link href="../../css/datepicker.css" rel="stylesheet" type="text/css">
		<link href="../../css/style.css" rel="stylesheet" type="text/css">
        <link href="../../css/font-awesome/css/all.css" rel="stylesheet" type="text/css">

    </head>
	
	<body>
	
		<div class="out-side">
		
			<div class="in-side back-white">
				<div class="row justify-content-center">
					<div class="col-md-12 head">
						<div class="logo">
							<img src="../../images/logo.png" width="50" class="circle-logo">
						</div>
						<div class="title">
							لوحة التحكم
						</div>
					</div>
					<div class="col-md-12 login-box">
						<a href="administrators.php" class="panel-link">
                            <i class="fa fa-user"></i>
							مديرين النظام
						</a>
						<a href="sections.php" class="panel-link">
                            <i class="fa fa-list"></i>
							الاقسام
						</a>
						<a href="cinemas.php" class="panel-link">
                            <i class="fa fa-film"></i>
							السينمات
						</a>
						<a href="movies.php" class="panel-link">
                            <i class="fa fa-check"></i>
							العروض
						</a>
					</div>
					<div class="col-md-12 externals">
						<a href="my.php" class="success-link">
                            <i class="fa fa-user"></i>
							البيانات الشخصية
						</a>
						<a href="out.php" class="danger-link">
                            <i class="fa fa-sign-out-alt"></i>
							تسجيل خروج
						</a>
					</div>
				</div>
			</div>
		
		</div>
	
		<script src="../../js/jquery-3.3.1.min.js"></script>
		<script src="../../js/bootstrap.js"></script>
		<script src="../../js/custom.js"></script>
	</body>
</html>