<?php

class Hall{
	
	private $name = null;
	private $id = 0, $cinema = 0, $rows = 0, $columns = 0;
	
	private $error;
	
	public function __construct($id = 0, $name = null, $columns = 0, $rows = 0, $cinema = 0){
		$this->id = $id;
		$this->name = $name;
		$this->rows = $rows;
		$this->columns = $columns;
		$this->cinema = $cinema;
	}
	
	public function add($name, $rows, $columns, $cinema){
		
		if(empty($name)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if(!is_numeric($columns) || !is_numeric($rows) || $columns < 1 || $rows < 1){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `hall` where `name` = '{$name}' and `cinema_id` = '{$cinema}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم العنصر مسجل مسبقا";
			return false;
		}
		
		$db->sql("INSERT INTO `hall`(`name`, `rows`, `columns`, `cinema_id`) VALUES('{$name}', '{$rows}', '{$columns}', '{$cinema}')");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function get($id = 0){
		
		if(!$id) $id = $this->id;
		
		$db = new db();
		
		$db->sql("select * from `hall` where `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows() != 1){
			$this->error = "العنصر غير مسجل";
			return false;
		}
		
		$user = $db->results()[0];
		
		$cinema = new Cinema();
		$cinema->getUser($user['cinema_id']);
		
		$this->id = $user['id'];
		$this->name = $user['name'];
		$this->rows = $user['rows'];
		$this->columns = $user['columns'];
		$this->cinema = $cinema;
		
		return true;
		
	}
	
	public function getAll($cinema){
		
		$db = new db();
		
		$db->sql("select * from `hall` where `cinema_id` = '{$cinema}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return [];
		}
		
		if(!$db->rows()){
			$this->error = "لا توجد نتائج";
			return [];
		}
		
		$halls = [];
		
		foreach($db->results() as $user){
			
			$cinema = new Cinema();
			$cinema->getUser($user['cinema_id']);
			
			$halls[] = new Hall($user['id'], $user['name'], $user['columns'], $user['rows'], $cinema);
			
		} 
		
		return $halls;
		
	}
	
	public function remove($id){
		
		if(!$this->get($id)){
			$this->error = "العنصر غير مسجل";
			return false;
		}
		
		$db = new db();
		
		$db->sql("DELETE FROM `hall` WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function update($id, $name, $rows, $columns){
		
		if(empty($name)){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		if(!is_numeric($columns) || !is_numeric($rows) || $columns < 1 || $rows < 1){
			$this->error = "من فضلك ادخل البيانات المطلوبة";
			return false;
		}
		
		$db = new db();
		
		$db->sql("select * from `hall` where `name` = '{$name}' and `id` <> '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		if($db->rows()){
			$this->error = "اسم العنصر مسجل مسبقا";
			return false;
		}
	
		$db->sql("UPDATE `hall` SET `name` = '{$name}', `rows` = '{$rows}', `columns` = '{$columns}' WHERE `id` = '{$id}'");
		
		if(!$db->execute()){
			$this->error = "خطأ فى التنفيذ";
			return false;
		}
		
		return true;
		
	}
	
	public function error(){
		return $this->error;
	}
	
	public function id(){
		return $this->id;
	}
	
	public function name(){
		return $this->name;
	}
	
	public function rows(){
		return $this->rows;
	}
	
	public function columns(){
		return $this->columns;
	}
	
	public function admin(){
		return $this->admin;
	}
	
}

?>